/**
 * trace-whatsapp-community.js
 * Order Status Page VIP WhatsApp Community Card & Auto-Redirect
 */
(function() {
  var communityUrl = "https://chat.whatsapp.com/lusvpn84y9x7tPj1";
  var delaySecs = 4;

  function initCard() {
    // Only run on Order Thank You / Status Page
    var isThankYou = window.location.pathname.indexOf('/thank_you') !== -1 || 
                     window.location.pathname.indexOf('/orders/') !== -1 ||
                     window.location.pathname.indexOf('/checkouts/') !== -1 ||
                     (window.Shopify && Shopify.Checkout && Shopify.Checkout.OrderStatus);

    if (!isThankYou) return;
    if (document.getElementById('whatsapp-vip-auto-card')) return;

    var cardHtml = `
      <div id="whatsapp-vip-auto-card" style="background: linear-gradient(135deg, #075e54 0%, #128c7e 100%); color: #ffffff; padding: 20px; border-radius: 12px; margin: 20px 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; box-shadow: 0 4px 15px rgba(0,0,0,0.12); position: relative;">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px;">
          <span style="background: rgba(255,255,255,0.2); padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; letter-spacing: 0.05em; text-transform: uppercase;">💬 Order Tracking & VIP Support</span>
          <span style="font-size: 18px;">🎉</span>
        </div>
        
        <h3 style="color: #ffffff; margin: 0 0 6px 0; font-size: 17px; font-weight: 700;">Order Confirmed! WhatsApp Open Ho Raha Hai...</h3>
        <p style="color: #e0f2f1; margin: 0 0 14px 0; font-size: 13px; line-height: 1.4;">
          Live order tracking updates, instant support aur VIP secret discounts ke liye WhatsApp join karein:
        </p>

        <div id="wa-timer-container" style="background: rgba(0,0,0,0.15); height: 6px; border-radius: 3px; overflow: hidden; margin-bottom: 14px;">
          <div id="wa-progress-bar" style="background: #25d366; height: 100%; width: 100%; transition: width 4s linear;"></div>
        </div>

        <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
          <a id="wa-direct-btn" href="${communityUrl}" target="_blank" rel="noopener" style="background-color: #25d366; color: #ffffff; font-weight: 700; font-size: 13.5px; padding: 10px 18px; border-radius: 25px; text-decoration: none; display: inline-block;">
            💬 Open WhatsApp Now (<span id="wa-countdown-text">4</span>s)
          </a>
          <button type="button" id="wa-cancel-btn" style="background: transparent; border: 1px solid rgba(255,255,255,0.4); color: #ffffff; font-size: 12.5px; padding: 9px 14px; border-radius: 25px; cursor: pointer;">
            ✖ Stay Here
          </button>
        </div>
      </div>
    `;

    var tempDiv = document.createElement('div');
    tempDiv.innerHTML = cardHtml.trim();
    var cardEl = tempDiv.firstChild;

    // Inject card into Shopify Order Status Page or top of content
    if (window.Shopify && Shopify.Checkout && Shopify.Checkout.OrderStatus) {
      Shopify.Checkout.OrderStatus.addContentBox(cardEl);
    } else {
      var container = document.querySelector('.content-box') || document.querySelector('.main__content') || document.body;
      if (container) container.insertBefore(cardEl, container.firstChild);
    }

    var cancelBtn = document.getElementById('wa-cancel-btn');
    if (cancelBtn) {
      cancelBtn.addEventListener('click', function() {
        cancelWaRedirect();
      });
    }

    // Don't auto-redirect if user already refreshed or cancelled
    if (sessionStorage.getItem('wa_redirect_cancelled') === 'true' || sessionStorage.getItem('wa_redirect_done') === 'true') {
      var timerContainer = document.getElementById('wa-timer-container');
      if (timerContainer) timerContainer.style.display = 'none';
      var countdownText = document.getElementById('wa-countdown-text');
      if (countdownText) countdownText.textContent = '0';
      return;
    }

    // Start countdown
    var timeLeft = delaySecs;
    var progressBar = document.getElementById('wa-progress-bar');
    var countdownText = document.getElementById('wa-countdown-text');
    
    setTimeout(function() {
      if (progressBar) progressBar.style.width = '0%';
    }, 50);

    var countdownInterval = setInterval(function() {
      timeLeft--;
      if (countdownText) countdownText.textContent = timeLeft;
      if (timeLeft <= 0) {
        clearInterval(countdownInterval);
        sessionStorage.setItem('wa_redirect_done', 'true');
        window.location.href = communityUrl;
      }
    }, 1000);

    function cancelWaRedirect() {
      clearInterval(countdownInterval);
      sessionStorage.setItem('wa_redirect_cancelled', 'true');
      var timerContainer = document.getElementById('wa-timer-container');
      if (timerContainer) timerContainer.style.display = 'none';
      if (cancelBtn) cancelBtn.textContent = '✓ Redirect Cancelled';
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCard);
  } else {
    initCard();
  }
})();
